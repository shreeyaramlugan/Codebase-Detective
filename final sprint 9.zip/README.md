# Codebase Detective

**Investigate codebases. Understand their structure. Discover what matters.**

Codebase Detective is a full-stack codebase investigation platform designed to help developers understand unfamiliar repositories through deterministic code analysis, source-grounded AI explanations and research-backed recommendations.

The project is being developed incrementally as a technically advanced portfolio project using TypeScript, Next.js, PostgreSQL and Prisma.

> **Current development status: Sprint 01 — Repository registration and indexing job management.**

The current indexing processor is a development-only metadata simulation. Actual source-code ingestion, parsing, dependency analysis and findings are planned for subsequent sprints.

---

## Table of Contents

- [Project Overview](#project-overview)
- [Technology Stack](#technology-stack)
- [Current Features](#current-features)
- [Architecture](#architecture)
- [Getting Started](#getting-started)
- [Environment Variables](#environment-variables)
- [Database Setup](#database-setup)
- [Development Commands](#development-commands)
- [Indexing Job Processing](#indexing-job-processing)
- [Testing](#testing)
- [Project Structure](#project-structure)
- [Development Roadmap](#development-roadmap)
- [Security Considerations](#security-considerations)
- [Current Limitations](#current-limitations)

---

## Project Overview

Understanding an unfamiliar codebase can be time-consuming, particularly when a developer needs to identify its architecture, dependencies, important components and potential risks.

Codebase Detective aims to make that investigation easier through:

1. Repository ingestion and source-code indexing.
2. Deterministic AST-based code analysis.
3. Symbol and dependency graph construction.
4. Rule-based code findings.
5. Source-grounded AI explanations.
6. Research-backed recommendations.

The platform prioritises reproducible analysis and traceable evidence rather than relying on AI-generated guesses.

## Technology Stack

| Layer                  | Technology                         |
| ---------------------- | ---------------------------------- |
| Language               | TypeScript                         |
| Frontend               | React                              |
| Framework              | Next.js App Router                 |
| Styling                | Tailwind CSS                       |
| Database               | PostgreSQL                         |
| ORM                    | Prisma                             |
| Authentication         | Better Auth                        |
| Repository provider    | GitHub API                         |
| Testing                | Vitest                             |
| Development processing | tsx                                |
| Hosting plan           | Vercel                             |
| Worker architecture    | Separate persistent worker planned |

## Current Features

### Implemented

- Email/password authentication.
- GitHub OAuth configuration.
- Protected dashboard access.
- Authenticated GitHub repository submission.
- Public repository metadata validation.
- Repository ownership enforcement.
- Duplicate repository detection.
- Transactional repository and indexing-job creation.
- Persistent indexing job records.
- Job lifecycle management:
  - PENDING
  - PROCESSING
  - COMPLETED
  - FAILED
- Retry handling with exponential backoff.
- Maximum attempt enforcement.
- Ownership-protected retry endpoint.
- Dashboard repository status display.
- Retry button with dashboard refresh.
- Development-only metadata processing simulation.

### Planned

- Repository snapshot ingestion.
- Source-code parsing using the TypeScript Compiler API.
- Symbol extraction and indexing.
- Dependency graph construction.
- Deterministic code findings.
- AI-powered explanations grounded in source evidence.
- Research-backed recommendations.
- Advanced codebase investigation features.

---

## Architecture

The application currently follows a modular monolith architecture.

```text
Browser
   |
   v
Next.js Application
   |
   +---- Authentication (Better Auth)
   |
   +---- Dashboard
   |
   +---- API Routes
   |        |
   |        +---- Repository Submission
   |        |
   |        +---- Indexing Job Retry
   |
   +---- Application Services
   |        |
   |        +---- GitHub Validation
   |        |
   |        +---- Job Lifecycle
   |
   +---- Prisma ORM
            |
            v
       PostgreSQL
```

A separate persistent worker will be introduced in a later sprint.

## Getting Started

### Prerequisites

Install the following:

- Node.js
- npm
- Git
- PostgreSQL database (local or hosted)
- GitHub account

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/codebase-detective.git
cd codebase-detective
```

Replace `YOUR_USERNAME` with the GitHub account hosting the project.

### 2. Install dependencies

```bash
npm install
```

### 3. Configure environment variables

Create a local environment file:

```bash
cp .env.example .env
```

On Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Populate the required values in `.env`.

Never commit `.env` or expose authentication secrets.

### 4. Configure the database

Create a PostgreSQL database and configure its connection string in `DATABASE_URL`.

Apply migrations:

```bash
npx prisma migrate dev
```

Generate the Prisma Client:

```bash
npx prisma generate
```

Check migration status:

```bash
npx prisma migrate status
```

### 5. Start the development server

```bash
npm run dev
```

Open:

http://localhost:3000

---

## Environment Variables

Create `.env` in the project root.

| Variable               | Description                     |
| ---------------------- | ------------------------------- |
| `DATABASE_URL`         | PostgreSQL connection string    |
| `BETTER_AUTH_SECRET`   | Authentication signing secret   |
| `BETTER_AUTH_URL`      | Better Auth base URL            |
| `NEXT_PUBLIC_APP_URL`  | Application base URL            |
| `GITHUB_CLIENT_ID`     | GitHub OAuth application ID     |
| `GITHUB_CLIENT_SECRET` | GitHub OAuth application secret |
| `AI_PROVIDER`          | AI provider selection           |
| `AI_MODEL`             | Selected AI model               |

### Example configuration

```env
DATABASE_URL="postgresql://USER:PASSWORD@HOST/DATABASE?sslmode=require"

BETTER_AUTH_SECRET="GENERATE_A_RANDOM_SECRET"
BETTER_AUTH_URL="http://localhost:3000"
NEXT_PUBLIC_APP_URL="http://localhost:3000"

GITHUB_CLIENT_ID="YOUR_GITHUB_CLIENT_ID"
GITHUB_CLIENT_SECRET="YOUR_GITHUB_CLIENT_SECRET"

AI_PROVIDER="mock"
AI_MODEL="mock-v1"
```

The mock AI configuration is a development placeholder. It does not represent a configured production AI provider.

Generate a secure authentication secret rather than using the example value.

---
## Quick Start

ThreatWeaver is developed locally using Windows, PowerShell and Docker Desktop.

### Prerequisites

Install the following:

| Tool | Requirement |
|---|---|
| Git | Installed |
| Python | 3.13.x |
| Node.js | 22.x |
| npm | 11.x |
| Docker Desktop | Installed and running |
| Docker Compose | Available through Docker Desktop |

### 1. Configure Environment Variables

Create the local environment file:

```powershell
Copy-Item .env.example .env
```

If `.env` already exists, do not overwrite it.

Configure the PostgreSQL password in `.env`.

See [Environment Setup](docs/environment_setup.md) for configuration and security requirements.

### 2. Start PostgreSQL

From the repository root:

```powershell
docker compose up -d
```

Check the database container:

```powershell
docker compose ps
```

Wait for the PostgreSQL health status to report `healthy`.

### 3. Start the Backend

Create and activate the Python virtual environment:

```powershell
py -m venv backend\.venv
.\backend\.venv\Scripts\Activate.ps1
```

Install development dependencies:

```powershell
python -m pip install -r backend\requirements-dev.txt
```

Start the FastAPI development server:

```powershell
python -m uvicorn app.main:app --app-dir backend --reload
```

Backend: `http://127.0.0.1:8000`

API documentation: `http://127.0.0.1:8000/docs`

Health check: `http://127.0.0.1:8000/health`

See [Backend Setup](docs/backend_setup.md) for detailed instructions.

### 4. Start the Frontend

Open a separate PowerShell terminal:

```powershell
cd frontend
npm ci
npm run dev
```

Frontend: `http://localhost:3000`

See [Frontend Setup](docs/frontend_setup.md) for detailed instructions.

### 5. Stop Development Services

Stop the frontend and backend servers using `CTRL + C` in their respective terminals.

Stop PostgreSQL:

```powershell
docker compose stop
```

To stop and remove the PostgreSQL container and Compose network:

```powershell
docker compose down
```

The named PostgreSQL volume is retained.

**Warning:** Do not use `docker compose down -v` unless you deliberately intend to delete the database volume and its data.

## Additional Documentation

| Document | Description |
|---|---|
| [Environment Setup](docs/environment_setup.md) | Environment variables and secrets management |
| [Backend Setup](docs/backend_setup.md) | Python, FastAPI and backend development |
| [Frontend Setup](docs/frontend_setup.md) | Next.js and frontend development |
| [Sprint Planning](docs/sprint%20planning/) | Sprint specifications |
| [Software Requirements](docs/SRS/) | Software Requirements Specification |
| [System Architecture](docs/System%20Architecture%20and%20Tech/) | Architecture and technical decisions |
| [Decision Log](docs/decision_log.md) | Project decision history |
| [Roadmap](roadmap.md) | Project development roadmap |

## Development Roadmap

The project is divided into ten implementation sprints.

| Sprint    | Focus                                              |
| --------- | -------------------------------------------------- |
| Sprint 00 | Project foundation and infrastructure              |
| Sprint 01 | Authentication, repositories and durable jobs      |
| Sprint 02 | Repository snapshot ingestion                      |
| Sprint 03 | Parsing and symbol indexing                        |
| Sprint 04 | Dependency and relationship analysis               |
| Sprint 05 | Deterministic findings and rules                   |
| Sprint 06 | Source-grounded AI investigation                   |
| Sprint 07 | Research-backed recommendations                    |
| Sprint 08 | Persistent worker and production resource controls |
| Sprint 09 | Deployment, hardening and final release            |

Features will be marked complete only after their acceptance criteria and verification tests pass.

---

## Security Considerations

The project follows these principles:

- Authentication required for protected application routes.
- Repository records are scoped to their owning user.
- Job operations verify repository ownership.
- Repository URLs are validated against the supported GitHub host.
- Repository and job creation use database transactions.
- Duplicate repository submissions are rejected.
- Retry operations enforce job lifecycle and attempt limits.
- Secrets are stored in environment variables, not source code.
- Repository source code will not be executed during indexing.

Additional production security controls will be introduced in later sprints.

---

## Current Limitations

Codebase Detective is actively under development.

At the current Sprint 01 stage:

- Only public GitHub repository registration is supported.
- Repository metadata is validated and stored.
- Indexing jobs are persisted and tracked.
- The development processor performs metadata simulation only.
- Actual source-code parsing is not implemented.
- Dependency graphs are not implemented.
- Deterministic findings are not implemented.
- Production AI investigation is not implemented.
- The persistent production worker is not implemented.
- Production deployment is deferred to Sprint 09.

The dashboard's completed indexing status must not be interpreted as completed code analysis.

---

## Project Philosophy

Codebase Detective is being built around a simple principle:

**Every insight should be explainable, traceable and grounded in evidence.**

The goal is not simply to ask AI what a codebase does. It is to build a system that can investigate the underlying code, identify relationships and explain its conclusions with supporting evidence.

Built with TypeScript, Next.js, PostgreSQL and a healthy amount of curiosity.

## Sprint Tracking

# Sprint 01 — Completion Record

**Sprint:** 01 — Repository Registration and Indexing Job Management  
**Status:** Complete — technical and manual acceptance checks passed  
**Automated tests:** 190 passed across 18 test files

### Delivered

- Email/password and GitHub OAuth authentication.
- Protected dashboard access.
- GitHub repository URL validation and metadata retrieval.
- Repository persistence with ownership enforcement.
- Duplicate repository prevention.
- Atomic repository and indexing-job creation.
- Persistent indexing-job lifecycle management.
- Retry scheduling, attempt limits and failure handling.
- Development-only metadata processing simulation.
- Dashboard repository status and retry integration.
- Integration tests for job lifecycle and concurrency.
- Updated README and environment documentation.

### Verification

- TypeScript: passed.
- ESLint: zero errors; five non-blocking warnings.
- Prisma schema validation: passed.
- Database migrations: up to date.
- Automated tests: 190/190 passed.
- Production build: passed.
- Prettier formatting: passed.
- Manual repository submission: passed.
- Manual duplicate submission: passed.
- Manual retry and dashboard refresh: passed.
- GitHub OAuth login: manually verified.

### Known limitations

The development processor validates repository metadata and simulates successful indexing. It does not yet download source code, parse files, construct dependency graphs or generate deterministic code findings.

These capabilities remain assigned to subsequent sprints.

### Completion decision

Sprint 01 acceptance checks are satisfied. The project is ready to proceed to Sprint 02, subject to the normal project-level review and version-control checkpoint.

### Sprint 02 — GitHub Ingestion & Repository Snapshots

**Status: Complete**

Implemented commit-based GitHub repository ingestion, immutable
repository snapshots, file classification, source storage,
content integrity verification, snapshot completeness tracking,
idempotent retries and owner-protected source retrieval.

### Sprint 03 — Code Intelligence Engine

**Status: Complete**

Implemented the deterministic, non-executing code intelligence engine using the TypeScript Compiler API. The engine parses JavaScript and TypeScript source files, including JSX and TSX, extracts code structures and symbols, resolves module dependencies, identifies statically traceable function calls, and generates a structured dependency graph.

**### Delivered**

- JavaScript, TypeScript, JSX and TSX parsing.
- AST-based extraction of functions, classes, methods, interfaces, types, variables and enums.
- Import, export and CommonJS analysis.
- Source-location tracking for extracted code structures and relationships.
- Stable symbol identification and symbol registry.
- Module resolution supporting relative imports, path aliases, package metadata and CommonJS.
- Explicit handling of resolved, unresolved, ambiguous and external dependencies.
- Static function-call relationship extraction, including uncertain call identification.
- Dependency graph generation with structured nodes, edges and relationship evidence.
- Relational persistence of analysis records, symbols, dependencies and diagnostics.
- Derived, regeneratable graph JSON read model.
- Immutable analysis runs, preserving previous results and failed runs.
- Analysis engine and parser version tracking.
- Foundation for future incremental analysis.
- Authenticated, owner-protected analysis and result retrieval.
- Parser, extraction, resolver, graph, integration and security tests.
- Updated technical documentation and README.

**### Completion decision**

Sprint 03 acceptance criteria are satisfied. The project now has a deterministic code intelligence foundation capable of transforming stored repository snapshots into structured, traceable code representations. The analysis engine does not execute repository code or rely on AI to establish code structures and dependencies.

The project is ready to proceed to Sprint 04, subject to the normal project-level review and version-control checkpoint.
Sprint 04 — Interactive Codebase Explorer

Status: Complete

Implemented the interactive Codebase Explorer, providing a user-facing interface for navigating and investigating repository snapshots and their associated code analysis results. The explorer connects the deterministic code intelligence produced in Sprint 03 to an integrated interface for browsing repository structure, inspecting source code, exploring symbols, visualising dependencies and searching across the codebase.

### Delivered

Repository overview displaying repository metadata, selected snapshots, commit information and analysis status.

Repository statistics covering files, symbols, dependencies and analysis results.

Hierarchical file explorer with nested folder navigation and file selection.

Source code viewer with syntax highlighting and line numbers.

Source navigation using extracted symbol locations.

Symbol explorer for browsing functions, classes, methods, interfaces, types, variables and enums.

Symbol search and filtering by relevant categories.

Symbol details and parent-child relationship navigation.

Interactive dependency graph using React Flow.

Graph navigation with zoom, pan, node selection and relationship inspection.

Graph filtering by node and edge types.

Visual distinction between confirmed and possible function-call relationships.

Handling of unresolved and external dependencies without inventing relationships.

Unified codebase search across files, paths, symbols, modules and exports.

Navigation between search results, source files, symbols and graph entities.

Integration with Sprint 02 repository snapshots and Sprint 03 analysis results.

Owner-protected access to repository and source information.

Handling of loading, empty, partial-analysis and error states.

Integration, navigation, security and regression testing.

Updated technical documentation and README.

### Completion decision

Sprint 04 acceptance criteria are satisfied. The project now provides an interactive interface for exploring repository structure and investigating the code intelligence generated by Sprint 03.

Users can navigate repository files, inspect source code, locate extracted symbols, explore dependency relationships and search across the analysed codebase. The explorer uses persisted analysis results and preserves the distinction between confirmed, possible and unresolved relationships.

The project is ready to proceed to Sprint 05, subject to the normal project-level review and version-control checkpoint.
### Sprint 05 — Deterministic Findings Engine

**Status: Complete**

Implemented the deterministic, rule-based findings engine, extending the code intelligence foundation from Sprint 03 to identify codebase issues and architectural observations. The engine evaluates analysed repository data against versioned rules, generates structured findings, preserves supporting source evidence and provides an interface for investigating findings and tracking changes across repository snapshots.

**### Delivered**

- Deterministic rule engine with structured rule registration and evaluation.
- Stable rule identifiers and version tracking.
- Dependency analysis rules for unresolved internal imports and circular dependencies.
- Unused export detection where supported by available analysis evidence.
- Code complexity metrics and configurable thresholds.
- Structural analysis for empty modules, unusually large modules and repeated patterns.
- Static security indicator rules with evidence-based reporting.
- Structured finding generation with categories, severity and descriptions.
- Finding evidence tracking linked to repository snapshots, analysis runs, files and symbols.
- Relational persistence of findings and supporting evidence.
- Finding deduplication within individual analysis runs.
- Findings dashboard with overview statistics and categorisation.
- Finding search and filtering by severity and category.
- Detailed finding views with supporting evidence and recommendations.
- Navigation from findings to affected source files and locations.
- Snapshot finding comparison.
- Classification of findings as new, persistent or resolved.
- Preservation of finding history across immutable analysis runs.
- Handling of partial analysis results to prevent unsupported resolution claims.
- Authenticated, owner-protected findings and evidence retrieval.
- Rule engine, finding generation, persistence, comparison, integration and security tests.
- Updated technical documentation and README.

**### Completion decision**

Sprint 05 acceptance criteria are satisfied. Codebase Detective can now evaluate analysed repositories using deterministic rules and generate structured, evidence-backed findings.

The platform identifies dependency issues, complexity concerns, structural observations and static security indicators. Findings are traceable to their originating rules, analysis runs and source evidence. The platform also supports investigating findings and tracking how they change across repository snapshots.

The project is ready to proceed to Sprint 06, subject to the normal project-level review and version-control checkpoint.
### Sprint 06 — AI Investigation Assistant

**Status: Complete**

Implemented the repository-specific AI Investigation Assistant, extending the deterministic code intelligence and findings capabilities from previous sprints with source-grounded AI explanations.

The assistant uses the Google Gemini API through a provider-independent integration and retrieves evidence from Codebase Detective's existing database records. It allows users to investigate repository structure, understand files and symbols, explore dependencies, examine deterministic findings and ask questions about potential code changes.

Responses are grounded in retrieved repository evidence and include validated source citations. The assistant preserves repository and snapshot context, supports persistent conversation management and enforces AI usage controls.

**### Delivered**

- Google Gemini API integration through a provider-independent AI architecture.
- Centralised AI provider and model configuration.
- Server-side AI credential management.
- Database-backed repository evidence retrieval.
- Retrieval of repository source files and documentation.
- Retrieval of code symbols and source locations.
- Retrieval of module dependencies and function-call relationships.
- Retrieval of deterministic findings and supporting evidence.
- Repository- and snapshot-scoped evidence retrieval.
- Relevant evidence selection and bounded context assembly.
- Repository-specific question answering and code explanations.
- Cross-file implementation and relationship explanations.
- Dependency and potential change-impact investigations.
- Explanations of deterministic findings using their underlying evidence.
- Explicit handling of confirmed, possible and unresolved relationships.
- Uncertainty handling when sufficient evidence is unavailable.
- Source-grounded AI responses with citation validation.
- Inline clickable source citations.
- Dedicated source references panel.
- Source navigation integrated with the Interactive Codebase Explorer.
- Snapshot-aware conversations with explicit snapshot switching.
- Persistent conversation and message history.
- Conversation creation, saving, renaming, archiving, restoration and deletion.
- Provider, model and available usage metadata recording.
- Daily user-level AI usage limits.
- Per-request limits for questions and evidence context.
- Request timeout, provider error and malformed response handling.
- Completed-response delivery rather than streaming.
- Loading, error and insufficient-evidence interface states.
- Repository ownership and conversation access enforcement.
- Snapshot and repository context isolation.
- Prompt-injection safeguards for repository source code and documentation.
- Protection against unsupported AI-generated findings, relationships and citations.
- Integration, retrieval, provider, citation, conversation and security testing.
- Updated technical documentation and README.

**### Architecture and implementation decisions**

| Area | Decision |
|---|---|
| AI provider | Google Gemini API |
| Evidence retrieval | Database-backed retrieval |
| Conversation snapshot behaviour | Explicit snapshot switching |
| Citation presentation | Inline citations and source references panel |
| Conversation history | Save, archive, rename and delete |
| AI usage controls | Daily and per-request limits |
| Response delivery | Display after completion |

**### Completion decision**

Sprint 06 acceptance criteria are satisfied. Codebase Detective now provides a repository-specific AI investigation assistant that uses existing deterministic analysis results and repository evidence to explain code structures, relationships and findings.

The assistant does not replace the deterministic analysis or findings engines. It operates as an investigative and explanatory layer, using retrieved evidence to generate answers and validated source citations.

Users can investigate their repositories through persistent, snapshot-aware conversations, navigate directly to cited source locations and manage their AI usage through daily and per-request limits.

The project is ready to proceed to Sprint 07 — Research Engine, subject to the normal project-level review and version-control checkpoint.

### Sprint 07 — Research Engine

**Status: Planned**

The next sprint will introduce a hybrid research engine combining official technical documentation and scholarly sources to support research-backed recommendations.

Research outputs will complement the deterministic findings and source-grounded AI investigation capabilities established in earlier sprints.
### Sprint 07 — Research Engine

**Status: Complete**

Implemented the hybrid Research Engine, extending Codebase Detective's deterministic findings and source-grounded AI investigation capabilities with external technical research and research-backed recommendations.

The engine combines official technical documentation with scholarly publications to investigate identified codebase issues and technical questions. It supports research through official documentation sources, Crossref and OpenAlex, while preserving source provenance, publication information, evidence and citation traceability.

Research discovery and recommendation generation are separate stages. Users can review collected sources before initiating recommendation generation. The engine combines approved research evidence with repository findings and codebase evidence to produce concise summaries and detailed technical recommendations.

**### Delivered**

- Hybrid research architecture combining official technical documentation and scholarly research.
- Official documentation research provider integration.
- Crossref scholarly publication discovery.
- OpenAlex scholarly publication discovery.
- Provider-independent research retrieval architecture.
- Official documentation discovery using available APIs, structured feeds and search-based retrieval.
- Scholarly publication metadata and abstract retrieval.
- Retrieval of openly accessible full text where permitted.
- Source normalisation and metadata preservation.
- Canonical URL and external identifier handling.
- Duplicate source detection and source reuse.
- Publication classification, including peer-reviewed publications, preprints and other scholarly material.
- Explicit identification of metadata-only, abstract-only and full-text source availability.
- Research query generation from supported deterministic findings.
- Manual technical research questions.
- Finding-based and repository-contextual research workflows.
- User-initiated research execution.
- Separation of source discovery and recommendation generation.
- Reviewable source collections before recommendation generation.
- Research evidence extraction and management.
- Source relevance and quality evaluation.
- Preservation of publisher, author, publication date, source type and retrieval metadata where available.
- Identification and disclosure of outdated or conflicting sources.
- Integration with the existing Google Gemini AI provider.
- Research synthesis combining deterministic findings, repository evidence and approved external research.
- Concise recommendation summaries.
- Detailed technical recommendations with supporting evidence.
- Recommendation rationale, expected benefits, trade-offs and implementation considerations.
- Repository and external research citation support.
- Citation and evidence validation to prevent unsupported claims.
- Immutable research runs preserving historical research results.
- Reusable research sources across separate research runs.
- Persistent research history.
- Recommendation saving and renaming.
- Recommendation acceptance and rejection.
- Recommendation archiving and restoration.
- Recommendation implementation-status tracking.
- Research overview dashboard and research history.
- Separate official documentation and scholarly source lists.
- Source evidence panel and detailed research reports.
- Per-request research limits.
- Daily user-level research limits.
- Provider rate-limit handling.
- Configurable source retrieval limits.
- Request timeouts and provider failure handling.
- Repository ownership and research access enforcement.
- Protection against external-source prompt injection.
- Handling of unavailable sources, incomplete research and insufficient evidence.
- Updated technical documentation and README.

**### Architecture and implementation decisions**

| Area | Decision |
|---|---|
| Research providers | Official documentation, Crossref and OpenAlex |
| Documentation retrieval | Hybrid APIs, structured feeds, search discovery and public-page retrieval |
| Scholarly retrieval | Metadata, abstracts and permitted open-access full text |
| Research scope | Supported deterministic findings and manual research questions |
| Research execution | User-initiated, with source review before synthesis |
| Source quality | Prioritise official documentation and peer-reviewed research |
| Recommendations | Concise summaries and detailed technical recommendations |
| Recommendation management | Save, rename, archive, accept, reject and mark as implemented |
| Research history | Reusable sources with immutable research runs |
| Usage controls | Per-request, daily user, provider and configurable source limits |
| Interface | Overview dashboard, separate source lists, evidence panel and detailed research reports |

**### Research integrity and limitations**

Research recommendations are grounded in retrieved repository evidence and external sources. The engine preserves the distinction between deterministic findings, repository evidence and external research.

Preprints and other scholarly material are labelled appropriately rather than presented as peer-reviewed research. Recommendations must disclose limitations where only metadata or abstracts are available. Conflicting, outdated or unavailable sources must not be represented as verified supporting evidence.

Marking a recommendation as implemented records the user's status update; it does not independently verify that the corresponding code change has been made or tested.

The research engine does not replace the deterministic findings engine or the AI Investigation Assistant. It extends them with externally sourced technical knowledge and research-backed recommendations.

**### Completion decision**

Sprint 07 acceptance criteria are satisfied. Codebase Detective now extends beyond repository analysis and AI-assisted investigation to support research-backed technical recommendations.

Users can initiate research from supported deterministic findings or submit their own technical questions, review discovered official and scholarly sources, and generate recommendations grounded in both repository evidence and external research.

Research runs preserve their history, sources remain reusable, and recommendations can be managed throughout their lifecycle. Citation validation, source provenance, usage controls and research-integrity safeguards help ensure that recommendations remain traceable and evidence-based.

The project is ready to proceed to Sprint 08 — Production Worker and Infrastructure, subject to the normal project-level review and version-control checkpoint.